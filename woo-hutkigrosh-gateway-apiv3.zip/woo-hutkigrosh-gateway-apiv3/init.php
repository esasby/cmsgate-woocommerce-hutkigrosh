<?php
if (!class_exists("apiv3\cmsgate\CmsPlugin"))
    require_once(dirname(__FILE__) . '/vendor/apiv3/cmsgate-core/src/apiv3/cmsgate/CmsPlugin.php');

use apiv3\cmsgate\CmsPlugin;
use apiv3\cmsgate\woocommerce\RegistryHutkigroshWoo;


(new CmsPlugin(dirname(__FILE__) . '/vendor', dirname(__FILE__)))
    ->setRegistry(new RegistryHutkigroshWoo())
    ->init();
