<?php
/**
 * Created by PhpStorm.
 * User: nikit
 * Date: 01.10.2018
 * Time: 12:05
 */

namespace apiv3\cmsgate\woocommerce;


use apiv3\cmsgate\descriptors\ModuleDescriptor;
use apiv3\cmsgate\descriptors\VendorDescriptor;
use apiv3\cmsgate\descriptors\VersionDescriptor;
use apiv3\cmsgate\hro\HROManager;
use apiv3\cmsgate\hutkigrosh\ConfigFieldsHutkigrosh;
use apiv3\cmsgate\hutkigrosh\hro\client\CompletionPanelHutkigroshHRO;
use apiv3\cmsgate\hutkigrosh\PaysystemConnectorHutkigrosh;
use apiv3\cmsgate\hutkigrosh\RegistryHutkigrosh;
use apiv3\cmsgate\view\admin\AdminViewFields;
use apiv3\cmsgate\woocommerce\hro\client\CompletionPanelHutkigroshHRO_Woo;
use apiv3\cmsgate\woocommerce\view\admin\ConfigFormWoo;

class RegistryHutkigroshWoo extends RegistryHutkigrosh
{
    /**
     * RegistryHutkigroshWoo constructor.
     */
    public function __construct()
    {
        $this->cmsConnector = new CmsConnectorWoo();
        $this->paysystemConnector = new PaysystemConnectorHutkigrosh();
    }

    public function init() {
        parent::init();
        HROManager::fromRegistry()->addImplementation(CompletionPanelHutkigroshHRO::class, CompletionPanelHutkigroshHRO_Woo::class);
    }

    /**
     * Переопделение для упрощения типизации
     * @return RegistryHutkigroshWoo
     */
    public static function getRegistry()
    {
        return parent::getRegistry();
    }


    public function createConfigForm()
    {
        $managedFields = $this->getManagedFieldsFactory()->getManagedFieldsExcept(AdminViewFields::CONFIG_FORM_COMMON, [ConfigFieldsHutkigrosh::shopName()]);
        $configForm = new ConfigFormWoo(
            AdminViewFields::CONFIG_FORM_COMMON,
            $managedFields
        );
        $configForm->addCmsManagedFields();
        return $configForm;
    }

    function getUrlAlfaclick($orderWrapper)
    {
        return admin_url('admin-ajax.php') . "?action=alfaclick";
    }

    function getUrlWebpay($orderWrapper)
    {
        $order = wc_get_order($orderWrapper->getOrderId());
        return $order->get_checkout_order_received_url();
    }

    public function createModuleDescriptor()
    {
        return new ModuleDescriptor(
            "hutkigrosh",
            new VersionDescriptor("4.1.5", "2026-07-29"),
            "Прием платежей через ЕРИП (сервис ХуткiГрош)",
            "https://github.com/eripby/cmsgate-woocommerce-hutkigrosh",
            VendorDescriptor::erip(),
            "Выставление пользовательских счетов в ЕРИП"
        );
    }
}