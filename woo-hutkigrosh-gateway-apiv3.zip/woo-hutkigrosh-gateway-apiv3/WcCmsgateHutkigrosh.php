<?php

use apiv3\cmsgate\hutkigrosh\ConfigFieldsHutkigrosh;
use apiv3\cmsgate\hutkigrosh\controllers\ControllerHutkigroshAddBill;
use apiv3\cmsgate\hutkigrosh\controllers\ControllerHutkigroshAlfaclick;
use apiv3\cmsgate\hutkigrosh\controllers\ControllerHutkigroshCompletionPanel;
use apiv3\cmsgate\hutkigrosh\controllers\ControllerHutkigroshNotify;
use apiv3\cmsgate\hutkigrosh\controllers\ControllerHutkigroshWebpayForm;
use apiv3\cmsgate\hutkigrosh\protocol\HutkigroshLoginRq;
use apiv3\cmsgate\hutkigrosh\protocol\HutkigroshProtocol;
use apiv3\cmsgate\hutkigrosh\utils\RequestParamsHutkigrosh;
use apiv3\cmsgate\hutkigrosh\wrappers\ConfigWrapperHutkigrosh;
use apiv3\cmsgate\lang\Translator;
use apiv3\cmsgate\utils\Logger;
use apiv3\cmsgate\view\admin\fields\ConfigFieldList;
use apiv3\cmsgate\woocommerce\WcCmsgate;
use apiv3\cmsgate\wrappers\OrderWrapper;

require_once('init.php');


if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class WcCmsgateHutkigrosh extends WcCmsgate
{
    function __construct()
    {
        parent::__construct();
        add_action('woocommerce_api_gateway_hutkigrosh', array($this, 'hutkigrosh_callback'));
        add_filter('woocommerce_thankyou_' . $this->id, array($this, 'hutkigrosh_thankyou_text'));
    }

    // Submit payment and handle response

    /**
     * @param OrderWrapper $orderWrapper
     * @throws Throwable
     */
    protected function process_payment_safe($orderWrapper)
    {
        if (empty($orderWrapper->getExtId())) {
            $controller = new ControllerHutkigroshAddBill();
            $controller->process($orderWrapper);
        }
    }

    function hutkigrosh_thankyou_text($order_id)
    {
        try {
            if (!ControllerHutkigroshWebpayForm::isSuccessReturnUrl()) {
                $controller = new ControllerHutkigroshCompletionPanel();
                $completionPanel = $controller->process($order_id);
                echo $completionPanel->build();
            }
        } catch (Throwable $e) {
            Logger::getLogger("payment")->error("Exception:", $e);
        }
    }

    public static function alfaclick_callback()
    {
        try {
            $controller = new ControllerHutkigroshAlfaclick();
            $controller->process($_POST[RequestParamsHutkigrosh::BILL_ID], $_POST[RequestParamsHutkigrosh::PHONE]);
        } catch (Throwable $e) {
            Logger::getLogger("alfaclick")->error("Exception: ", $e);
        }
        wp_die();
    }

    public function hutkigrosh_callback()
    {
        try {
            $billId = $_GET[RequestParamsHutkigrosh::PURCHASE_ID];
            $controller = new ControllerHutkigroshNotify();
            $controller->process($billId);
        } catch (Throwable $e) {
            Logger::getLogger("callback")->error("Exception:", $e);
        }
    }

    public static function service_provider()
    {
        try {
            $cfg = ConfigWrapperHutkigrosh::fromRegistry();
            $cfg->setHutkigroshApiToken($_GET[RequestParamsHutkigrosh::API_TOKEN]);
            // Учитываем текущий (возможно еще не сохраненный) выбор sandbox в форме настроек,
            // иначе запрос ушел бы на боевой/тестовый endpoint по старому сохраненному значению.
            // ВНИМАНИЕ: переопределение только в памяти запроса — sandbox НЕ пишется в БД
            // до явного "Сохранить" (не сохраняем настройки частями).
            if (isset($_GET[RequestParamsHutkigrosh::SANDBOX])) {
                $cfg->setSandboxOverride($_GET[RequestParamsHutkigrosh::SANDBOX] === 'yes');
            }
            $hg = new HutkigroshProtocol($cfg);
            $billLogin = new HutkigroshLoginRq();
            // Принудительно свежий запрос + сохранение в кеш (скрытое поле настроек),
            // чтобы при выставлении счета metadata бралась из кеша без повторных запросов.
            $hg->checkProviderMetadata($billLogin, true);
            if (empty($hg->rqProviderMetadata)) {
                // API вернул пустой ответ/ошибку (типично HTTP 401 при рассогласовании
                // токена и режима Sandbox). Возвращаем структурированную ошибку — иначе
                // на стороне JS null ломает выполнение и алерт не показывается.
                echo json_encode(array(
                    'message' => 'Нет данных от ХуткiГрош (HTTP ' . (int)$hg->rqCode
                        . '). Проверьте API Token и соответствие режима Sandbox.'
                ));
                die;
            }
            echo json_encode( $hg->rqProviderMetadata );
            die;
        } catch (Throwable $e) {
            Logger::getLogger("callback")->error("Exception:", $e);
        }
    }
}