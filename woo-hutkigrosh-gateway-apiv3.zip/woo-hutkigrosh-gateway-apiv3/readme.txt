=== Hutkigrosh API v3 Gateway for WooCommerce ===
Contributors: nmekh
Tags: commerce, woocommerce, hutkigrosh, shopping, gateway, erip
Stable tag: 4.1.5
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Woocommerce ERIP (Belarus) integration via Hutkigrosh Gateway

== Description ==
Hutkigrosh™ — payment service for invoicing in AIS *Raschet* (ERIP) Belarus.
After invoicing you clients will be available for payment by a plastic card and electronic money, at any of the bank branches, cash desks, ATMs, payment terminals, in the electronic money system, through Internet banking, M-banking, Internet acquiring.

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/woo-hutkigrosh-gateway-apiv3` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the Woocommerce->Settings->Payments screen to configure the plugin

== Changelog ==
= 2.0.1 =
* Bug fix: automatic order status update

= 2.1.0 =
* Completion page is wrapped by accordion element

= 2.1.1 =
* Bug fix for php 5.6 compatibility

= 2.2.0 =
* QR-code generation support

= 2.2.2 =
* Bug fix: correct eripid validation
* New feature: instructions section + managed completion text

= 2.2.3 =
* Bug fix: order status update in sandbox mode
* New feature: external css-file support for completion page

= 2.5.0 =
* New feature: adaptive theme completion page
* New feature: auto-expandable section on completion page (if only one section is enabled)

= 2.5.1 =
* Bug fix: Escaping "&" in product name

= 2.5.2 =
* Bug fix: Escaping « » in product name

= 2.5.3 =
* Bug fix: Resolving conflict with "Custom Order Numbers for WooCommerce"

= 2.5.4 =
* Bug fix: Order status update callback now working with custom order number

= 3.0.0 =
* Cmsgate-core library integration

= 3.11.3 =
* Cmsgate-core library update
* jquery http link changed to https
* Webpay success return to empty page

= 3.11.4 =
* Wordpress 5.8 compatibility check

= 3.11.5 =
* missing file fix

= 3.11.6 =
* elementTab bugfix

= 4.0.0 =
* Update to latest core version
* Wordpress 6.2 compatibility
* HRO support

= 4.0.1 =
* PHP warnings fix

= 4.0.2 =
* Wordpress 6.5.2 compatibility
* Woocommerce 8.8.2 compatibility

= 4.0.3 =
* Wordpress 6.9 compatibility
* Woocommerce 10.4.3 compatibility
* remove Alphaclick section

= 4.0.4 =
* Hutkigosh API v3 update

= 4.1.5 =
* _apiv3: Уникальный invoiceNumber при выставлении счета (формат <orderId>W<5 цифр>) — устраняет ошибку API "Invoice with this number already exists" на общем аккаунте ХуткiГрош (локалка/прод) и при сбросе БД
* _apiv3: Сохранение фактического invoiceNumber в мета заказа и небросающий 3-шаговый матчинг колбэка оплаты (notify): по invoiceNumber, по extId, по извлеченному orderId
* _apiv3: Фикс wc_doing_it_wrong / "Order properties should not be accessed directly" под HPOS в поиске заказа по номеру (страница "Заказ принят")
* _apiv3: Фикс PHP 8 warnings в ResourceUtils::getVirtualPath (Undefined variable $real_part/$virtual_part, Deprecated str_replace(null))
* _apiv3: В инструкции клиенту и тексте "Счет выставлен" показывается реальный номер счета из ХуткiГрош
* _apiv3: Фикс PHP 8.4 implicit-nullable deprecated (log4php + cmsgate-core) — устраняет Deprecated-нотисы при установке/активации
* _apiv3: Кеш service-provider/metadata в скрытом поле настроек (обновляется при "Актуализации") — запрос metadata больше не уходит при каждом выставлении счета
* _apiv3: Фикс PHP 8.2 deprecated "${var}" интерполяции строк в ResourceUtils (getResourceUrl)