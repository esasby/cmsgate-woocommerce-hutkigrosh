<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
/*
Plugin Name: Hutkigrosh API v3 Gateway for WooCommerce
Plugin URI: https://github.com/esasby/cmsgate-woocommerce-hutkigrosh
Description: Модуль для выставления счетов в систему ЕРИП через сервис ХуткiГрош
Version: 4.1.5
Author: ESAS
Author Email: n.mekh@alcosi.eu
Text Domain: woocommerce-hutkigrosh-payments
WC requires at least: 9.0.0
WC tested up 10.4.3
*/

// Include our Gateway Class and register Payment Gateway with WooCommerce
add_action('plugins_loaded', 'wc_cmsgate_hutkigrosh_init', 0);
function wc_cmsgate_hutkigrosh_init()
{
    // If the parent WC_Payment_Gateway class doesn't exist
    // it means WooCommerce is not installed on the site
    // so do nothing
    if (!class_exists('WC_Payment_Gateway')) return;
    // If we made it this far, then include our Gateway Class
    include_once('WcCmsgateHutkigrosh.php');
    // Now that we have successfully included our class,
    // Lets add it too WooCommerce
    add_filter('woocommerce_payment_gateways', 'wc_cmsgate_hutkigrosh_add_payment_gateway');

    function wc_cmsgate_hutkigrosh_add_payment_gateway($methods)
    {
        $methods[] = 'WcCmsgateHutkigrosh';
        return $methods;
    }
}

/* HPOS & Blocks Compatible */
add_action( 'before_woocommerce_init', function () {
    try {
        if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
        }
    }catch ( \Exception $e ) {}
});

add_action( 'woocommerce_blocks_loaded', function() {
    include_once('WcCmsgateHutkigroshPaymentMethod.php');
    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function (\Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry) {
            $payment_method_registry->register(new WcCmsgateHutkigroshPaymentMethod());
        }
    );
} ); // WooCommerce Blocks

// Add custom action links
require_once dirname(__FILE__) . '/vendor/apiv3/cmsgate-woocommerce-lib/src/apiv3/cmsgate/woocommerce/cmsgate-woocommerce-hooks.php';
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'cmsgate_hutkigrosh_settings_link');

/**
 * Custom text on the receipt page.
 */
add_action('wp_ajax_alfaclick', 'alfaclick_callback');
add_action('wp_ajax_nopriv_alfaclick', 'alfaclick_callback');
function alfaclick_callback()
{
    return WcCmsgateHutkigrosh::alfaclick_callback();
}

add_action('wp_ajax_hutkigrosh_service_provider', 'service_provider');
function service_provider()
{
    if (class_exists('WcCmsgateHutkigrosh')) {
        header('Content-Type: application/json');
        WcCmsgateHutkigrosh::service_provider();
    } else {
        wp_send_json_error('Class not found');
    }
}

/**
 * Скачивание лог-файлов модуля.
 * Один файл — отдаётся напрямую как .log, несколько — архивом .zip.
 * Вызывается кнопкой "Скачать логи" рядом с "Сохранить изменения".
 */
add_action('admin_post_hutkigrosh_download_logs', 'hutkigrosh_download_logs');
function hutkigrosh_download_logs()
{
    if (!current_user_can('manage_woocommerce')) {
        wp_die('Доступ запрещён.');
    }
    check_admin_referer('hutkigrosh_download_logs');

    $pluginDir = dirname(__FILE__);
    $logs = array();
    try {
        $di = new RecursiveDirectoryIterator($pluginDir, FilesystemIterator::SKIP_DOTS);
        $it = new RecursiveIteratorIterator($di);
        foreach ($it as $f) {
            if ($f->isFile() && preg_match('/\.log$/i', $f->getFilename())) {
                $rel = str_replace('\\', '/', substr($f->getPathname(), strlen($pluginDir) + 1));
                $logs[$f->getPathname()] = 'hutkigrosh/' . $rel;
            }
        }
    } catch (Throwable $e) {
        $logs = array();
    }

    if (empty($logs)) {
        wp_die('Лог-файлы не найдены.');
    }

    nocache_headers();
    if (count($logs) === 1) {
        $path = key($logs);
        header('Content-Type: text/plain; charset=utf-8');
        header('Content-Disposition: attachment; filename="hutkigrosh.log"');
        header('Content-Length: ' . filesize($path));
        @readfile($path);
    } else {
        $tmp = tempnam(sys_get_temp_dir(), 'hghlogs_');
        $zip = new ZipArchive();
        if ($tmp && $zip->open($tmp, ZipArchive::OVERWRITE) === true) {
            foreach ($logs as $full => $virt) {
                $zip->addFile($full, $virt);
            }
            $zip->close();
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="hutkigrosh-logs.zip"');
            header('Content-Length: ' . filesize($tmp));
            @readfile($tmp);
        }
        @unlink($tmp);
    }
    exit;
}

/**
 * Сохранение скрытого поля metadata: на странице оно в base64url, в БД хранится JSON.
 * Вызывается после штатного process_admin_options (приоритет 20), чтобы перечитать
 * уже сохраненные настройки и не затереть их устаревшей копией из singleton-хранилища.
 */
add_action('woocommerce_update_options_payment_gateways_hutkigrosh', 'hutkigrosh_save_provider_metadata', 20);
function hutkigrosh_save_provider_metadata()
{
    $field = 'woocommerce_hutkigrosh_provider_metadata';
    if (!isset($_POST[$field])) {
        return;
    }
    $b64 = wp_unslash($_POST[$field]);
    $json = '';
    if (is_string($b64) && $b64 !== '') {
        $decoded = base64_decode(strtr($b64, '-_', '+/'));
        if ($decoded !== false) {
            $arr = json_decode($decoded, true);
            if (is_array($arr)) {
                $json = json_encode($arr, JSON_UNESCAPED_UNICODE);
            }
        }
    }
    $optionName = 'woocommerce_hutkigrosh_settings';
    $settings = get_option($optionName, array());
    if (!is_array($settings)) {
        $settings = array();
    }
    $settings['provider_metadata'] = $json;
    update_option($optionName, $settings);
}