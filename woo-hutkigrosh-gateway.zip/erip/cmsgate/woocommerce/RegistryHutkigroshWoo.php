<?php
/**
 * Created by PhpStorm.
 * User: nikit
 * Date: 01.10.2018
 * Time: 12:05
 */

namespace erip\cmsgate\woocommerce;


use erip\cmsgate\descriptors\ModuleDescriptor;
use erip\cmsgate\descriptors\VendorDescriptor;
use erip\cmsgate\descriptors\VersionDescriptor;
use erip\cmsgate\hro\HROManager;
use erip\cmsgate\hutkigrosh\ConfigFieldsHutkigrosh;
use erip\cmsgate\hutkigrosh\hro\client\CompletionPanelHutkigroshHRO;
use erip\cmsgate\hutkigrosh\PaysystemConnectorHutkigrosh;
use erip\cmsgate\hutkigrosh\RegistryHutkigrosh;
use erip\cmsgate\view\admin\AdminViewFields;
use erip\cmsgate\woocommerce\hro\client\CompletionPanelHutkigroshHRO_Woo;
use erip\cmsgate\woocommerce\view\admin\ConfigFormWoo;

class RegistryHutkigroshWoo extends RegistryHutkigrosh
{
    /**
     * RegistryHutkigroshWoo constructor.
     */
    public function __construct()
    {
        $this->cmsConnector = new CmsConnectorWoo();
        $this->paysystemConnector = new PaysystemConnectorHutkigrosh();
    }

    public function init() {
        parent::init();
        HROManager::fromRegistry()->addImplementation(CompletionPanelHutkigroshHRO::class, CompletionPanelHutkigroshHRO_Woo::class);
    }

    /**
     * Переопделение для упрощения типизации
     * @return RegistryHutkigroshWoo
     */
    public static function getRegistry()
    {
        return parent::getRegistry();
    }


    public function createConfigForm()
    {
        $managedFields = $this->getManagedFieldsFactory()->getManagedFieldsExcept(AdminViewFields::CONFIG_FORM_COMMON, [ConfigFieldsHutkigrosh::shopName()]);
        $configForm = new ConfigFormWoo(
            AdminViewFields::CONFIG_FORM_COMMON,
            $managedFields
        );
        $configForm->addCmsManagedFields();
        return $configForm;
    }

    function getUrlAlfaclick($orderWrapper)
    {
        return admin_url('admin-ajax.php') . "?action=alfaclick";
    }

    function getUrlWebpay($orderWrapper)
    {
        $order = wc_get_order($orderWrapper->getOrderId());
        return $order->get_checkout_order_received_url();
    }

    public function createModuleDescriptor()
    {
        return new ModuleDescriptor(
            "hutkigrosh",
            new VersionDescriptor("4.0.3", "2026-01-19"),
            "Прием платежей через ЕРИП (сервис ХуткiГрош)",
            "https://github.com/eripby/cmsgate-woocommerce-hutkigrosh",
            VendorDescriptor::erip(),
            "Выставление пользовательских счетов в ЕРИП"
        );
    }
}