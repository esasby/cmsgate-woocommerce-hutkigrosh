<?php
if (!class_exists("erip\cmsgate\CmsPlugin"))
    require_once(dirname(__FILE__) . '/vendor/erip/cmsgate-core/src/erip/cmsgate/CmsPlugin.php');

use erip\cmsgate\CmsPlugin;
use erip\cmsgate\woocommerce\RegistryHutkigroshWoo;


(new CmsPlugin(dirname(__FILE__) . '/vendor', dirname(__FILE__)))
    ->setRegistry(new RegistryHutkigroshWoo())
    ->init();
